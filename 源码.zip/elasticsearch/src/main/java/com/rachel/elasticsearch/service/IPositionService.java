package com.rachel.elasticsearch.service;

import com.rachel.elasticsearch.dao.Position;

import java.io.IOException;
import java.util.List;

public interface IPositionService {

    boolean addDataToEs() throws IOException;

    List<Position> searchByPositionName(String positionName) throws IOException;
}
