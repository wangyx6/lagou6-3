package com.rachel.elasticsearch.dao;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Data
@ToString
@Table(name = "position")
public class Position {

    private String companyName;

    @Id
    private Double id;

    private String positionAdvantage;
    private Double companyId;
    private String positionName;
    private String salary;
    private Double salaryMin;
    private Double salaryMax;
    private Double salaryMonth;
    private String education;
    private String workYear;
    private String jobNature;
    private Date createTime;
    private String email;
    private String publishTime;
    private boolean isEnable;
    private boolean isIndex;
    private String city;

}
