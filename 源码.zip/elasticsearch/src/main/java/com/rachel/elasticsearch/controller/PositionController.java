package com.rachel.elasticsearch.controller;

import com.rachel.elasticsearch.dao.Position;
import com.rachel.elasticsearch.service.IPositionService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@Controller
public class PositionController {

    @Resource
    private IPositionService positionService;

    // 测试页面
    @GetMapping({"/","/index"})
    public   String  indexPage(){
        return  "index";
    }

    @GetMapping("/position/data/add")
    public String addDataToEs() throws IOException {
        positionService.addDataToEs();
        return "success";
    }

    @GetMapping("/position/{positionName}")
    @ResponseBody
    public List<Position> searchPosition(@PathVariable String positionName) throws IOException {
        return positionService.searchByPositionName(positionName);
    }
}
