package com.rachel.elasticsearch;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ElasticSearchRestClient {

    @Value("${server.elasticsearch.uri}")
    private String elasticSearchUri;

    @Bean
    public RestHighLevelClient highLevelClient(){

        String[] urls = elasticSearchUri.split(",");
        HttpHost[] httpHostArray = new HttpHost[urls.length];
        for (int i=0; i<urls.length; i++) {
            String[] urlValue = urls[i].split(":");
            httpHostArray[i] = new HttpHost(urlValue[0], Integer.parseInt(urlValue[1]));
        }
        return new RestHighLevelClient(RestClient.builder(httpHostArray));
    }
}
