package com.rachel.elasticsearch.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.rachel.elasticsearch.dao.Position;
import com.rachel.elasticsearch.dao.PositionDao;
import com.rachel.elasticsearch.service.IPositionService;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class PositionServiceImpl implements IPositionService {

    @Resource
    private RestHighLevelClient restHighLevelClient;

    @Resource
    private PositionDao positionDao;

    @Override
    public boolean addDataToEs() throws IOException {
        // 查询出所有的数据
        List<Position> positionList = positionDao.findAll();

        BulkRequest request = new BulkRequest("position-index");
        for (Position position : positionList) {
            IndexRequest indexRequest = new IndexRequest();
            String jsonString = JSONObject.toJSONString(position);
            indexRequest.source(jsonString, XContentType.JSON);
            request.add(indexRequest);
            if(request.numberOfActions() == 1000){
                restHighLevelClient.bulk(request, RequestOptions.DEFAULT);
                request.requests().clear();
            }
        }
        restHighLevelClient.bulk(request, RequestOptions.DEFAULT);
        return true;
    }

    @Override
    public List<Position> searchByPositionName(String positionName) throws IOException {
        List<Position> retList = new ArrayList<>();
        SearchRequest searchRequest = new SearchRequest("position-index");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        ;
        searchSourceBuilder.query(QueryBuilders.matchQuery("positionName", positionName));
        searchSourceBuilder.from(0);
        searchSourceBuilder.size(5);
        searchRequest.source(searchSourceBuilder);
        SearchResponse response = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        addHitToList(response.getHits().getHits(), retList);
        int total = (int) response.getHits().getTotalHits().value;
        if(total < 5){
            int overLeft = 5 - total;
            SearchSourceBuilder searchSourceBuilderLeft = new SearchSourceBuilder();
            searchSourceBuilderLeft.query(QueryBuilders.matchQuery("positionAdvantage", "美女多、员工福利好"));
            searchSourceBuilderLeft.from(0);
            searchSourceBuilderLeft.size(overLeft);
            searchRequest.source(searchSourceBuilderLeft);
            SearchResponse responseLeft = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            addHitToList(responseLeft.getHits().getHits(), retList);
        }
        return retList;
    }

    public void addHitToList(SearchHit[] searchHits,  List<Position> retList){
        for (SearchHit searchHit : searchHits) {
            String json = searchHit.getSourceAsString();
            Position position = JSONObject.parseObject(json, Position.class);
            retList.add(position);
        }
    }
}
